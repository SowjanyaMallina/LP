package com.virtusa.dbconnnection;


import java.sql.Connection;

import java.sql.DriverManager;


import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;




public class JDBCConnection
{
	static final Logger logger = Logger.getLogger(JDBCConnection.class);

	String connectionUrl = "jdbc:oracle:thin:@localhost:1521:xe";
	String dbUser = "ramya";
	String dbPwd = "ramya";
	String driverClassName ="oracle.jdbc.driver.OracleDriver";
	
	private static JDBCConnection jdbcconnection = null;
	
	public JDBCConnection() {
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");
		try {
			Class.forName(driverClassName);
		} catch (ClassNotFoundException e) {
			logger.fatal(e);
		}
	}
	
	public Connection getConnection() throws SQLException {
		
		Connection conn = null;
		conn = DriverManager.getConnection(connectionUrl, dbUser, dbPwd);
		return conn;
	}
	
	public static JDBCConnection getInstance() {
		if (jdbcconnection == null) {
			jdbcconnection = new JDBCConnection();
		}
		return jdbcconnection;
	}
	

}
