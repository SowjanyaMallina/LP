package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.Batch;

import com.virtusa.dbconnnection.JDBCConnection;

public class BatchDao implements BatchInter
{
	Logger log = Logger.getLogger(BatchDao.class);
	
	
	Connection connection = null;
	PreparedStatement ptmt = null;
	ResultSet resultSet = null;
	
	
	private Connection getConnection() throws SQLException 
	{
		Connection conn;
		conn = JDBCConnection.getInstance().getConnection();
		return conn;
	}

	@Override
	public int addBatchDetails(Batch batch) 
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");
		
		 int status = 0;
		    try
		    {
		    	String queryString = "INSERT INTO batch(batchid,batchname,venueid,mentorid,cid) VALUES(?,?,?,?,?)";
				connection = getConnection();
				ptmt = connection.prepareStatement(queryString);
				ptmt.setInt(1, batch.getbatchid());
				ptmt.setString(2, batch.getbatchname());
				ptmt.setInt(3, batch.getvenueid());
				ptmt.setInt(4, batch.getmentorid());
				ptmt.setInt(5, batch.getcid() );
				status = ptmt.executeUpdate();
				log.info("event added successfully");
				
		    }catch (SQLException e) {
				log.fatal(e);
		    	
			} finally {
				try {
					if (ptmt != null)
						ptmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {
					log.fatal(e);
				} catch (Exception ex) {
					log.fatal(ex);
				}

			}
			return status;
	}

	@Override
	public List<Batch> getAllBatch()
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");
		List <Batch> batchlist = new ArrayList();
		try
		{
			String queryString = "SELECT * FROM batch";
			connection = getConnection();
			ptmt = connection.prepareStatement(queryString);
			resultSet  = ptmt.executeQuery();
			while(resultSet.next())
			{
				Batch b11 = new Batch();
				b11.setbatchid(resultSet.getInt(1));
				b11.setbatchname(resultSet.getString(2));
				b11.setmentorid(resultSet.getInt(3));
				b11.setvenueid(resultSet.getInt(4));
				b11.setcid(resultSet.getInt(5));
				
				
				
				batchlist.add(b11);
			}
		}catch (SQLException e) {
			log.fatal(e);
		} finally {
			try {
				if(resultSet != null)
					resultSet.close();
			}catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}try {
				if (ptmt != null)
					ptmt.close();
			}catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}try {
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}

		}
		
		return batchlist;
	}
	
}
