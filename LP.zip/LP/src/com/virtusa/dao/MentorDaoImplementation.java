package com.virtusa.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;



import com.virtusa.bean.Mentor;
import com.virtusa.dbconnnection.*;

public class MentorDaoImplementation implements MentorDao
{
	Logger log = Logger.getLogger(MentorDaoImplementation.class);


	Connection connection = null;
	PreparedStatement ptmt = null;
	ResultSet resultSet = null;
	
	
	private Connection getConnection() throws SQLException 
	{
		Connection conn;
		conn = JDBCConnection.getInstance().getConnection();
		return conn;
	}
	
	
	@Override
	public int addMentorDetails(Mentor mentor) 
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		 int status = 0;
		    try
		    {
		    	String queryString = "INSERT INTO mentor(mentorpass,mentorid,phno,email,mentorname,venueid) VALUES(?,?,?,?,?,?)";
				connection = getConnection();
				ptmt = connection.prepareStatement(queryString);
				ptmt.setString(1, mentor.getmentorpass());
				ptmt.setInt(2, mentor.getmentorid());
				ptmt.setLong(3, mentor.getPhno());
				ptmt.setString(4, mentor.getEmail());
				ptmt.setString(5, mentor.getmentorname());
				ptmt.setInt(6, mentor.getvenueid());
				status = ptmt.executeUpdate();
				log.info("Event added successfully");
				
		    }catch (SQLException e) {
				log.fatal(e);
			} finally {
				try {
					if (ptmt != null)
						ptmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {
					log.fatal(e);
				} catch (Exception ex) {
					log.fatal(ex);
				}

			}
			return status;
	}


	@Override
	public List<Mentor> getAllMentor() 
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		List <Mentor> mentorlist = new ArrayList();
		try
		{
			String queryString = "SELECT * FROM mentor";
			connection = getConnection();
			ptmt = connection.prepareStatement(queryString);
			resultSet  = ptmt.executeQuery();
			while(resultSet.next())
			{
				Mentor m1 = new Mentor();
				m1.setmentorpass(resultSet.getString(1));
				m1.setmentorid(resultSet.getInt(2));
				m1.setPhno(resultSet.getLong(3));
				m1.setEmail(resultSet.getString(4));
				m1.setmentorname(resultSet.getString(5));
				m1.setvenueid(resultSet.getInt(6));
				
				mentorlist.add(m1);
			}
		}catch (SQLException e) {
			log.fatal(e);
		} finally {
			try {
				if(resultSet != null)
					resultSet.close();
			}catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}try {
				if (ptmt != null)
					ptmt.close();
			}catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}try {
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}

		}
		
		return mentorlist;
	}
	
	
		
}
