package com.virtusa.dao;

import java.util.List;


import com.virtusa.bean.Venue;

public interface VenueInter
{
	Venue addVenueDetails(Venue venue);
	List <Venue> getAllVenue();


	
}
