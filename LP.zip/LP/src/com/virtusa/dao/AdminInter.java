package com.virtusa.dao;

import com.virtusa.bean.Batch;
import com.virtusa.bean.Mentor;
import com.virtusa.bean.Venue;

public interface AdminInter 
{
	 void addMentor(Mentor m);
	 void addVenue(Venue v);
	 void allocateVenue(Batch b);
	 void viewVenue(Venue v);
	 void viewMentor(Mentor m);
}
