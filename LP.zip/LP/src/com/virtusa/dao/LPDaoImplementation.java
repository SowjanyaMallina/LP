package com.virtusa.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.LP;
import com.virtusa.dbconnnection.JDBCConnection;

public class LPDaoImplementation implements LPDao
{
	
	Logger log = Logger.getLogger(LPDaoImplementation.class);
	String basepath="G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties";
	Connection connection = null;
	PreparedStatement ptmt = null;
	ResultSet resultSet = null;
	
	
	private Connection getConnection() throws SQLException 
	{
		Connection conn;
		conn = JDBCConnection.getInstance().getConnection();
		return conn;
	}
	
	@Override
	public int addLPDetails(LP lp)
	{
		  PropertyConfigurator.configure(basepath);

		int status = 0;
	    try
	    {
	    	String queryString = "INSERT INTO lp(lppass,lpid,lpname,phno,email,batchid,venueid) VALUES(?,?,?,?,?,?,?)";
			connection = getConnection();
			ptmt = connection.prepareStatement(queryString);
			ptmt.setString(1,lp.getlppass() );
			ptmt.setInt(2, lp.getlpid());
			ptmt.setString(3, lp.getLPName());
			ptmt.setInt(4, lp.getPhno());
			ptmt.setString(5, lp.getEmail());
			ptmt.setInt(6, lp.getbatchid());
			ptmt.setInt(7, lp.getvenueid());
			status = ptmt.executeUpdate();
			log.info("Event Added Successfully");
			
	    }catch (SQLException e) {
			log.fatal(e);
		} finally {
			try {
				if (ptmt != null)
					ptmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}

		}
		return status;
	}
	
	
	
	@Override
	public int updateLp(LP l1)
	{
		PropertyConfigurator.configure(basepath);
		int status = 0;
		try
		{
			String queryString = "UPDATE lp SET phno=?,email=? WHERE lpid=?";
			connection = getConnection();
			ptmt = connection.prepareStatement(queryString);
			
			ptmt.setInt(1, l1.getPhno());
			ptmt.setString(2, l1.getEmail());
			ptmt.setInt(3, l1.getlpid());
			status = ptmt.executeUpdate();
		}catch (SQLException e) {
			log.fatal(e);
		} finally {
			try {
				if (ptmt != null)
					ptmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}

		}
		return status;
	}
	
	
	@Override
	public int deleteLp(LP lp) 
	{
		PropertyConfigurator.configure(basepath);
		int status =0;
		try
		{
				String queryString = "DELETE FROM lp WHERE lpid=?";
				connection = getConnection();
				ptmt = connection.prepareStatement(queryString);
				ptmt.setInt(1, lp.getlpid());
				status=ptmt.executeUpdate();
		}catch (SQLException e) {
			log.fatal(e);
		} finally {
			try {
				if (ptmt != null)
					ptmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}
		}
		return status;
	}

	@Override
	public List<LP> getAllLPS()
	{
		PropertyConfigurator.configure(basepath);
	   List<LP> lPlist=new ArrayList<LP>();
		try
		{
			String queryString = "SELECT * FROM lp";
			connection = getConnection();
			ptmt = connection.prepareStatement(queryString);
			resultSet = ptmt.executeQuery();
			while(resultSet.next())
			{
				LP l1 = new LP();
				l1.setlppass(resultSet.getString(1));
				l1.setlpid(resultSet.getInt(2));
				l1.setLPName(resultSet.getString(3));
				l1.setPhno(resultSet.getInt(4));
				l1.setEmail(resultSet.getString(5));
				l1.setbatchid(resultSet.getInt(6));
				l1.setvenueid(resultSet.getInt(7));
				lPlist.add(l1);
			}
		}catch (SQLException e) {
			log.fatal(e);
		} finally {
			try {
				if(resultSet != null)
					resultSet.close();
			}catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}try {
				if (ptmt != null)
					ptmt.close();
			}catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}try {
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}

		}
		
		return lPlist;
	}

	@Override
	public LP getLPById(int lpid)
	{
		PropertyConfigurator.configure(basepath);
		LP l1 = new LP();
		try
		{
				String queryString = "SELECT * FROM lp WHERE lpid=?";
				connection = getConnection();
				ptmt = connection.prepareStatement(queryString);
				ptmt.setInt(1, lpid);
				resultSet= ptmt.executeQuery();
				if(resultSet.next())
				{
					l1.setlpid(resultSet.getInt(1));
					l1.setLPName(resultSet.getString(2));
					l1.setPhno(resultSet.getInt(3));
					l1.setEmail(resultSet.getString(4));
					l1.setbatchid(resultSet.getInt(5));
					l1.setvenueid(resultSet.getInt(6));
				}
				
				}catch (SQLException e) {
					log.fatal(e);
				} finally {
					try {
						if(resultSet != null)
							resultSet.close();
					}catch (SQLException e) {
						log.fatal(e);
					} catch (Exception ex) {
						log.fatal(ex);
					}try {
						if (ptmt != null)
							ptmt.close();
					}catch (SQLException e) {
						log.fatal(e);
					} catch (Exception ex) {
						log.fatal(ex);
					}try {
						if (connection != null)
							connection.close();
					} catch (SQLException e) {
						log.fatal(e);
					} catch (Exception ex) {
						log.fatal(ex);
					}

				}
		return l1;
	}
	
	
	}
	

