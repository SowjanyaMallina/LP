package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.virtusa.bean.Module;
import com.virtusa.dbconnnection.JDBCConnection;

public class ModuleDao implements ModuleInter
{
	Logger log = Logger.getLogger(ModuleDao.class);
	Connection connection = null;
	PreparedStatement ptmt = null;
	ResultSet resultSet = null;
	
	
	private Connection getConnection() throws SQLException 
	{
		Connection conn;
		conn = JDBCConnection.getInstance().getConnection();
		return conn;
	}

	@Override
	public int addModuleDetails(Module module) 
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		 int status = 0;
		    try
		    {
		    	String queryString = "INSERT INTO batch(moduleid,modulename,batchid,schedule) VALUES(?,?,?,?)";
				connection = getConnection();
				ptmt = connection.prepareStatement(queryString);
				ptmt.setInt(1, module.getmoduleid());
				ptmt.setString(2, module.getmodulename());
				ptmt.setInt(3, module.getbatchid());
				ptmt.setString(4, module.getSchedule());
		
				status = ptmt.executeUpdate();
				log.info("Event Added Successfully");
		    }catch (SQLException e) {
				log.fatal(e);
			} finally {
				try {
					if (ptmt != null)
						ptmt.close();
					if (connection != null)
						connection.close();
				} catch (SQLException e) {
					log.fatal(e);
				} catch (Exception ex) {
					log.fatal(ex);
				}

			}
			return status;
	}

	@Override
	public List<Module> getAllModule() 
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		List <Module> modulelist = new ArrayList();
		try
		{
			String queryString = "SELECT * FROM module";
			connection = getConnection();
			ptmt = connection.prepareStatement(queryString);
			resultSet  = ptmt.executeQuery();
			while(resultSet.next())
			{
				Module m1 = new Module();
				m1.setmoduleid(resultSet.getInt(1));
				m1.setmodulename(resultSet.getString(2));
				m1.setbatchid(resultSet.getInt(3));
				m1.setSchedule(resultSet.getString(4));
				modulelist.add(m1);
			}
		}catch (SQLException e) {
			log.fatal(e);
		} finally {
			try {
				if(resultSet != null)
					resultSet.close();
			}catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}try {
				if (ptmt != null)
					ptmt.close();
			}catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}try {
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}

		}
		
		return modulelist;
	}
	
}
