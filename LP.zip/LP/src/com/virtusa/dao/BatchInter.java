package com.virtusa.dao;

import java.util.List;

import com.virtusa.bean.Batch;


public interface BatchInter
{
	int addBatchDetails(Batch batch);
	List <Batch> getAllBatch();
}
