package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.Course;
import com.virtusa.dbconnnection.JDBCConnection;

public class CourseDao implements CourseInter
{
	Logger log = Logger.getLogger(CourseDao.class);
	Connection connection = null;
	PreparedStatement ptmt = null;
	ResultSet resultSet = null;
	
	
	private Connection getConnection() throws SQLException 
	{
		Connection conn;
		conn = JDBCConnection.getInstance().getConnection();
		return conn;
	}

	@Override
	public int addcourseDetails(Course course) 
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

	    int status = 0;
	    try
	    {
	    	String queryString = "INSERT INTO corse(cid,cname) VALUES(?,?)";
			connection = getConnection();
			ptmt = connection.prepareStatement(queryString);
			ptmt.setInt(1, course.getcid());
			ptmt.setString(2, course.getcname());
			status = ptmt.executeUpdate();
			log.info("Event Added Successfully");
	    }catch (SQLException e) {
			log.fatal(e);
		} finally {
			try {
				if (ptmt != null)
					ptmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}

		}
		return status;
	}

	@Override
	public List<Course> getAllCourse() 
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");
		List <Course> courselist = new ArrayList();
		try
		{
			String queryString = "SELECT * FROM corse";
			connection = getConnection();
			ptmt = connection.prepareStatement(queryString);
			resultSet  = ptmt.executeQuery();
			while(resultSet.next())
			{
				Course c1 = new Course();
				c1.setcid(resultSet.getInt(1));
				c1.setcname(resultSet.getString(2));
				courselist.add(c1);
			}
		}catch (SQLException e) {
			log.fatal(e);
		} finally {
			try {
				if(resultSet != null)
					resultSet.close();
			}catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}try {
				if (ptmt != null)
					ptmt.close();
			}catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}try {
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}
		}
		
		return courselist;
	}
	
	
	
}
