package com.virtusa.dao;

import java.util.List;


import com.virtusa.bean.Mentor;



public interface MentorDao 
{
	int addMentorDetails(Mentor mentor);
	List <Mentor> getAllMentor();
	

}
