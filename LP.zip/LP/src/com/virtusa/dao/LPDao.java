package com.virtusa.dao;

import java.util.List;


import com.virtusa.bean.LP;

public interface LPDao
{
	int addLPDetails(LP lp);
	int updateLp(LP l1);
	int deleteLp(LP lp);
	LP getLPById(int lpID);
	List<LP> getAllLPS();
	 
}
