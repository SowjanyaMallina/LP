package com.virtusa.dao;

import java.util.List;

import com.virtusa.bean.Course;

public interface CourseInter 
{
	int addcourseDetails(Course course);
	List <Course> getAllCourse();
}
