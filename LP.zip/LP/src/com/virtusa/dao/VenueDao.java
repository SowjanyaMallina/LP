package com.virtusa.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;



import com.virtusa.bean.Venue;
import com.virtusa.dbconnnection.JDBCConnection;

public class VenueDao implements VenueInter
{
	Logger log = Logger.getLogger(VenueDao.class);
	
	Connection connection = null;
	PreparedStatement ptmt = null;
	ResultSet resultSet = null;
	
	
	private Connection getConnection() throws SQLException 
	{
		Connection conn;
		conn = JDBCConnection.getInstance().getConnection();
		return conn;
	}

	@Override
	public Venue addVenueDetails(Venue venue) {
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		try {
			String queryString = "INSERT INTO venuedetails(venueid,venueaddress) VALUES(?,?)";
			connection = getConnection();
			ptmt = connection.prepareStatement(queryString);
			ptmt.setInt(1, venue.getvenueid());
			ptmt.setString(2, venue.getvenueaddress());
			ptmt.executeUpdate();
			log.info("Event Added Successfully");
		} catch (SQLException e) {
			log.fatal(e);
		} finally {
			try {
				if (ptmt != null)
					ptmt.close();
				if(resultSet != null)
					resultSet.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}

		}
		return venue;
	}

	@Override
	public List<Venue> getAllVenue()
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		List <Venue> venuelist = new ArrayList();
		try
		{
			String queryString = "SELECT * FROM venuedetails";
			connection = getConnection();
			ptmt = connection.prepareStatement(queryString);
			resultSet = ptmt.executeQuery();
			while(resultSet.next())
			{
				Venue v1 = new Venue();
				v1.setvenueid(resultSet.getInt(1));
				v1.setvenueaddress(resultSet.getString(2));
				
				
				venuelist.add(v1);
			}
			
		}catch (SQLException e) {
			log.fatal(e);
		} finally {
			try {
				if(resultSet != null)
					resultSet.close();
			}catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}try {
				if (ptmt != null)
					ptmt.close();
			}catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}try {
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				log.fatal(e);
			} catch (Exception ex) {
				log.fatal(ex);
			}

		}
		
		return venuelist;
	}
	
	
	
}
