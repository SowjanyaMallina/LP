package com.virtusa.dao;

import com.virtusa.bean.Batch;
import com.virtusa.bean.Mentor;
import com.virtusa.bean.Venue;

public class AdminDao implements AdminInter
{
	private  MentorDao md = new MentorDaoImplementation();
	private VenueInter vd = new VenueDao();
	private BatchInter bi = new BatchDao();

	@Override
	public void addMentor(Mentor m) 
	{
		md.addMentorDetails(m);
	}

	@Override
	public void addVenue(Venue v)
	{
		vd.addVenueDetails(v);
		
	}

	@Override
	public void allocateVenue(Batch b) 
	{
		bi.addBatchDetails(b);
		
	}

	@Override
	public void viewVenue(Venue v)
	{
		vd.getAllVenue();
		
	}

	@Override
	public void viewMentor(Mentor m) 
	{

		md.getAllMentor();
		
	}
	
}
