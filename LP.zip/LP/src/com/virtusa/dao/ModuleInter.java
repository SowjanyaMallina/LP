package com.virtusa.dao;

import java.util.List;

import com.virtusa.bean.Module;

public interface ModuleInter 
{
	int addModuleDetails(Module module);
	List <Module> getAllModule();
	
}
