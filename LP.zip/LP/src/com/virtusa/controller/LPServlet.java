package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.LP;
import com.virtusa.dao.LPDaoImplementation;


/**
 * Servlet implementation class LPServlet
 */
@WebServlet("/LPServlet")
public class LPServlet extends HttpServlet {
	static final Logger logger = Logger.getLogger(LPServlet.class);

	
	@Override

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");
      
		try {
		PrintWriter out = response.getWriter();
		
		
		String lpPassword = request.getParameter("lppass");
		int lpID = Integer.parseInt(request.getParameter("lpid"));
		String lpNamme = request.getParameter("lpname");
		int lpPhno = Integer.parseInt(request.getParameter("phno"));
		String lpEmail = request.getParameter("email");
		int lPBatchId = Integer.parseInt(request.getParameter("batchid"));
		int venueID = Integer.parseInt(request.getParameter("venueid"));
		
		
		LP lp = new LP();
		
		lp.setlppass(lpPassword);
		lp.setlpid(lpID);
		lp.setLPName(lpNamme);
		lp.setPhno(lpPhno);
		lp.setEmail(lpEmail);
		lp.setbatchid(lPBatchId);
		lp.setvenueid(venueID);
		
		int status=0;
		LPDaoImplementation d = new LPDaoImplementation();
		status=d.addLPDetails(lp);
		if(status>=0)
		{
			out.print("<p> Lps added successfully..</p>");
		}
		else
		{
			out.println("unbale to add Lps");
		}
		out.close();
		}catch(Exception e)
		{
			logger.fatal(e);
		}
	}

}
