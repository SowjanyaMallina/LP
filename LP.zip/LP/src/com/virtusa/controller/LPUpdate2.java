package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.LP;
import com.virtusa.dao.LPDaoImplementation;


@WebServlet("/LPUpdate2")
public class LPUpdate2 extends HttpServlet {
	static final Logger logger = Logger.getLogger(LPUpdate2.class);

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		 response.setContentType("text/html"); 
		 try {
		 PrintWriter out = response.getWriter();
		 
		 int lPID = Integer.parseInt(request.getParameter("lpid"));
		 int phoneNO = Integer.parseInt(request.getParameter("phno"));
		 String email = request.getParameter("email");
		 
		 LP l1 = new LP();
		 l1.setlpid(lPID);
		 l1.setPhno(phoneNO);
		 l1.setEmail(email);
		 
		 LPDaoImplementation lpd = new LPDaoImplementation();
		 
		 int state = lpd.updateLp(l1);

		if(state>0)
		 {
			 response.sendRedirect("LpView");
		 }
		 else
		 {
			 out.print("Sorry!nunable to update record");
		 }
		 
		 out.close();
	}catch(Exception e)
		 {
		     logger.fatal(e);
		 }
	}

}
