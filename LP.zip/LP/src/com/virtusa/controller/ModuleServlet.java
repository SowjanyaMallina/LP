package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.virtusa.bean.Module;
import com.virtusa.dao.ModuleDao;


@WebServlet("/ModuleServlet")
public class ModuleServlet extends HttpServlet {
	static final Logger logger = Logger.getLogger(ModuleServlet.class);
	@Override

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		response.setContentType("text/html"); 
		try
		{
		PrintWriter out = response.getWriter();
		int moduleID = Integer.parseInt(request.getParameter("moduleid"));
		String modulename = request.getParameter("modulename");
		int batchID = Integer.parseInt(request.getParameter("batchid"));
		String schedule = request.getParameter("schedule");
		
		
		Module m1 = new Module();
		m1.setmoduleid(moduleID);
		m1.setmodulename(modulename);
		m1.setbatchid(batchID);
		m1.setSchedule(schedule);
		
		ModuleDao md = new ModuleDao();
		int state = md.addModuleDetails(m1);
		if(state>=0)
		{
			out.print("added successfully");
		}
		else
		{
			out.print("check ur errors");
		}
		
		out.close();
		}catch(Exception e)
		{
			logger.fatal(e);
		}
	}

}
