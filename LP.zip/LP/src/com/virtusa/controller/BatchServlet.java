package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.Batch;
import com.virtusa.dao.BatchDao;


@WebServlet("/BatchServlet")
public class BatchServlet extends HttpServlet {
	static final Logger logger = Logger.getLogger(BatchServlet.class);

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");		
		response.setContentType("text/html"); 
		try
		{
		PrintWriter out = response.getWriter();
		int batchID = Integer.parseInt(request.getParameter("batchid"));
		String batchName = request.getParameter("batchname");
		int venueID = Integer.parseInt(request.getParameter("venueid"));
		int mentorID = Integer.parseInt(request.getParameter("mentorid"));
		int courseID = Integer.parseInt(request.getParameter("cid"));
		
		Batch b1 = new Batch();
		b1.setbatchid(batchID);
		b1.setbatchname(batchName);
		b1.setvenueid(venueID);
		b1.setmentorid(mentorID);
		b1.setcid(courseID);
		
		int state =0;
		BatchDao bd = new BatchDao();
		state = bd.addBatchDetails(b1);
		if(state>=0)
		{
			out.print("added successfully");
		}
		else
		{
			out.print("check ur errors");
		}
		
		out.close();
		}catch(Exception e)
		{
			logger.fatal(e);
		}
		
	}

}
