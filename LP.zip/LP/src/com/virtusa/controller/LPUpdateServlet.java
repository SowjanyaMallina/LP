package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.virtusa.dao.LPDaoImplementation;

@WebServlet("/LPUpdateServlet")
public class LPUpdateServlet extends HttpServlet {
	static final Logger logger = Logger.getLogger(LPUpdateServlet.class);

	
	@Override
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");
		response.setContentType("text/html"); 
		try {
		PrintWriter out = response.getWriter();
		 out.println("<h1>Update Lp</h1>");
		
		int lpID = Integer.parseInt(request.getParameter("lpid"));
		
		LPDaoImplementation lpd = new LPDaoImplementation();
		  lpd.getLPById(lpID);
		
		out.print("<form action='LPUpdate2' method='post'>");
		out.print("<table>");
		out.print("<tr><th>LPID</th><td><input type = 'text' name='lpid' value='"+"'/></td></tr>");
		out.print("<tr><th>PHNO</th><td><input type = 'tel' name='phno' value='"+"'/></td></tr>");
		out.print("<tr><th>EMAIL</th><td><input type = 'email' name='email' value='"+"'/></td></tr>");
		out.print("<tr><td colspan='2'><input type='submit' value='Edit & Save '/></td></tr>");
		out.print("</table>");
		out.print("</form>");
		out.close();


		}catch(Exception e)
		{
			logger.fatal(e);
		}
		
	}
		
		
	}


