package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.Batch;

import com.virtusa.dao.BatchDao;



@WebServlet("/ViewBatch")
public class ViewBatch extends HttpServlet {
	static final Logger logger = Logger.getLogger(ViewBatch.class);

	@Override

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		response.setContentType("text/html"); 
		try
		{
		PrintWriter out = response.getWriter();
		
		out.println("<h1>View Batch List</h1>");
		BatchDao bd1 = new BatchDao();
		List <Batch> batchlist = bd1.getAllBatch();
		out.print("<table border ='1' width='100%'");
		out.print("<tr><th>BatchID</th><th>BatchName</th><th>MentorID</th><th>VenueId</th><th>CourseId</tr>");
		for(Batch b1 : batchlist) 
		{
		out.print("<tr><td>"+b1.getbatchid()+"</td><td>"+b1.getbatchname()+"</td><td>"+b1.getmentorid()+
				"</td><td>"+b1.getvenueid()+"</td><td>"+b1.getcid()+"</td></tr>");
		}
		out.print("</table>");
		out.close();
		}catch(Exception e)
		{
			logger.fatal(e);
		}
	}

	
}
