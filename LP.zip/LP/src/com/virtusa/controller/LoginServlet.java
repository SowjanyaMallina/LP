 package com.virtusa.controller;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;



import com.virtusa.dbconnnection.JDBCConnection;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	static final Logger logger = Logger.getLogger(LoginServlet.class);
	
	@Override

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{

			PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");
			logger.debug("Sample debug message");
			logger.info("Sample info message");
			logger.warn("Sample warn message");
			logger.error("Sample error message");
			logger.fatal("Sample fatal message");
			Connection conn = null;
			PreparedStatement stmt=null;
			ResultSet resultSet = null;
		response.setContentType("text/html");
		
		String utype = request.getParameter("utype").trim();
		String userName = request.getParameter("username").trim();
		String password = request.getParameter("password").trim();
		logger.info("*********************************************");
		logger.info(userName);
		 logger.info(password);
		 logger.info("*********************************************");
       try {
		JDBCConnection j = new JDBCConnection();
			conn = j.getConnection();
			stmt = conn.prepareStatement("select utype from logindetails where username=? and password =?");
			stmt.setString(1, userName);
			stmt.setString(2, password);
			resultSet  = stmt.executeQuery();
			logger.info(conn+"   *******      ");
		if(resultSet.next())
		{
		  String s=resultSet.getString(1);
		  logger.info(s+"     MMMMMMMMMMMMMMMMMMMMMMMMMMMMMM"+utype);
			if(s.equalsIgnoreCase(utype))
			{
			  logger.info(s+"     MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMPPPPPPPPPP"+utype);
				if(utype.equalsIgnoreCase("admin"))
				{
					logger.info(s+"     MMMMMMMMMMMMMMMMMMMMMMMMMMMMMOOOOOOOOOOOOOOOOM"+utype);
				RequestDispatcher rd = request.getRequestDispatcher("/AdminOP.html");
				rd.forward(request, response);
					
				}
			
				else if(utype.equalsIgnoreCase("mentor"))
				{
				RequestDispatcher rd = request.getRequestDispatcher("MentorOp.html");
				rd.forward(request, response);
				}
				else if(utype.equalsIgnoreCase("lp"))
				{
				RequestDispatcher rd = request.getRequestDispatcher("LpOp.html");
				rd.forward(request, response);
				}
				else
				{
					RequestDispatcher rd = request.getRequestDispatcher("index.html");
					rd.forward(request, response);
					logger.info("<center><font color='blue'>Invalid credrntials</center>");
					logger.info("HELLLLLLLLLLLLLLLLLLLLOOOOOOOOOOOOOOOOOOOO>>>>>>>>>>>>>>");	
					logger.error("Invalid credrntials");
				}

		}
	}
			else {
				RequestDispatcher rd = request.getRequestDispatcher("index.html");
				rd.forward(request, response);
				logger.info("<center><font color='blue'>Invalid credrntials</center>");
				logger.info("HELLLLLLLLLLLLLLLLLLLLOOOOOOOOOOOOOOOOOOOO>>>>>>>>>>>>>>");	
				logger.error("Invalid credrntials");
				  
				
				logger.info("***********************************");
				logger.info("<script>alert('Login fail')</script>");
				logger.info("***********************************");
				
			}
       }catch(SQLException e)
       {
    	   logger.fatal(e);
       }
       catch(Exception ex)
       {
    	   logger.fatal(ex);
       }
       finally {
    	   try {
				if(resultSet != null)
					resultSet.close();
			}catch (SQLException e) {
				logger.fatal(e);
			} catch (Exception ex) {
				logger.fatal(ex);
			}try {
				if (stmt != null)
					stmt.close();
			}catch (SQLException e) {
				logger.fatal(e);
			} catch (Exception ex) {
				logger.fatal(ex);
			}try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				logger.fatal(e);
			} catch (Exception ex) {
				logger.fatal(ex);
			}

		}
		
	}
}
		
		
		
		
	
	


