package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.Module;
import com.virtusa.dao.ModuleDao;


@WebServlet("/ViewModule")
public class ViewModule extends HttpServlet {
	static final Logger logger = Logger.getLogger(ViewModule.class);

	@Override

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		response.setContentType("text/html"); 
		try
		{
		PrintWriter out = response.getWriter();

		out.println("<h1>View Module List</h1>");
		ModuleDao bd1 = new ModuleDao();
		List <Module> modulelist = bd1.getAllModule();
		out.print("<table border ='1' width='100%'");
		out.print("<tr><th>ModuleID</th><th>ModuleName</th><th>BatchID</th><th>Schedule</th></tr>");
		for(Module b1 : modulelist) 
		{
		out.print("<tr><td>"+b1.getmoduleid()+"</td><td>"+b1.getmodulename()+"</td><td>"+b1.getbatchid()+
				"</td><td>"+b1.getSchedule()+"</td></tr>");
		}
		out.print("</table>");
		out.close();
	}catch(Exception e)
		{
		  logger.fatal(e);
		}
	}

	

}
