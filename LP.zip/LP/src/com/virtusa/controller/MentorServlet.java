package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.Mentor;
import com.virtusa.dao.MentorDaoImplementation;

/**
 * Servlet implementation class MentorServlet
 */
@WebServlet("/MentorServlet")
public class MentorServlet extends HttpServlet {
	static final Logger logger = Logger.getLogger(MentorServlet.class);
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		response.setContentType("text/html"); 
		try {
		PrintWriter out = response.getWriter();
		out.print("entering");
		String mentorPassword = request.getParameter("mentorpass");
		int mentorID = Integer.parseInt(request.getParameter("mentorid"));
		int phoneNum = Integer.parseInt(request.getParameter("phno"));
		String email = request.getParameter("email");
		String mentorName = request.getParameter("mentorname");
		int venueID = Integer.parseInt(request.getParameter("venueid"));
		
		Mentor m1 = new Mentor();
		m1.setmentorpass(mentorPassword);
		m1.setmentorid(mentorID);
		m1.setPhno(phoneNum);
		m1.setEmail(email);
		m1.setmentorname(mentorName);
		m1.setvenueid(venueID);
		
		
		int status=0;
		MentorDaoImplementation md = new MentorDaoImplementation();
		status=md.addMentorDetails(m1);
		
		if(status>=0)
		{
			out.print("added successfully");
		}
		else
		{
			out.print("check ur errors");
		}
		
		out.close();

		}catch(Exception e)
		{
			logger.fatal(e);
		}
	}

}
