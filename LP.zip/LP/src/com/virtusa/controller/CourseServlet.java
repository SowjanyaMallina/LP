package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.Course;
import com.virtusa.dao.CourseDao;

/**
 * Servlet implementation class CourseServlet
 */
@WebServlet("/CourseServlet")
public class CourseServlet extends HttpServlet {
	static final Logger logger = Logger.getLogger(CourseServlet.class);

	@Override

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		 response.setContentType("text/html"); 
		 try {
			PrintWriter out = response.getWriter();
			int courseID = Integer.parseInt(request.getParameter("cid"));
			String courseName= request.getParameter("cname");
			Course c1 = new Course();
			c1.setcid(courseID);
			c1.setcname(courseName);
			int state =0;
			CourseDao cd = new CourseDao();
			state = cd.addcourseDetails(c1);
			if(state>0)
			{
				out.print("course details added ");
			}
			else
			{
				out.print("not added");
			}
			
			out.close();
		 }catch(Exception e)
		 {
			 logger.fatal(e);
		 }
	}

}
