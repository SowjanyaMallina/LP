package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.Course;
import com.virtusa.dao.CourseDao;


@WebServlet("/ViewCourse")
public class ViewCourse extends HttpServlet {
	static final Logger logger = Logger.getLogger(ViewCourse.class);

	@Override

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		 response.setContentType("text/html"); 
		 try
		 {
			PrintWriter out = response.getWriter();
			
			out.println("<h1>View Course List</h1>");
			CourseDao cd1 = new CourseDao();
			List <Course> courselist = cd1.getAllCourse();
			out.print("<table border ='1' width='100%'");
			out.print("<tr><th>ID</th><th>Name</th></tr>");
			for(Course c1 : courselist) 
			{
			out.print("<tr><td>"+c1.getcid()+"</td><td>"+c1.getcname()+"</td></tr>");
			}
			out.print("</table>");
			out.close();
	     }catch(Exception e) {
	    	 logger.fatal(e);
	     }
	}

	

}
