package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.Mentor;

import com.virtusa.dao.MentorDaoImplementation;



@WebServlet("/ViewMentor")
public class ViewMentor extends HttpServlet {
	static final Logger logger = Logger.getLogger(ViewMentor.class);

	@Override

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		response.setContentType("text/html"); 
		try
		{
		PrintWriter out = response.getWriter();
		
		out.println("<h1>View Mentor List</h1>");
		
		MentorDaoImplementation md1 = new MentorDaoImplementation();
		List <Mentor> mentorlist = md1.getAllMentor();
		out.print("<table border ='1' width='100%'");
		out.print("<tr><th>mentorpassword</th><th>mentorid</th><th>PHNO</th><th>Email></th><th>mentorname></th><th>VenueId</th></tr>");
		for(Mentor m1 : mentorlist) 
		{
		out.print("<tr><td>"+m1.getmentorpass()+"</td><td>"+m1.getmentorid()+"</td><td>"+m1.getPhno()+"</td><td>"
		+m1.getEmail()+"</td><td>"+m1.getmentorname()+"</td><td>"+m1.getvenueid()+"</td></tr>");
		}
		out.print("</table>");
		out.close();
	}catch(Exception e)
		{
		  logger.fatal(e);
		}
	}
	

	
}
