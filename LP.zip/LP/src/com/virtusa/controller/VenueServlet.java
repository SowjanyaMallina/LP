package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.Venue;
import com.virtusa.dao.VenueDao;

/**
 * Servlet implementation class VenueServlet
 */
@WebServlet("/VenueServlet")
public class VenueServlet extends HttpServlet {
	static final Logger logger = Logger.getLogger(VenueServlet.class);
	
	
	@Override

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		
		 response.setContentType("text/html");
		 try {
		PrintWriter out = response.getWriter();
		int venueID = Integer.parseInt(request.getParameter("venueid"));
		String venueAddress= request.getParameter("venueaddress");
		
		Venue v1 = new Venue();
		v1.setvenueid(venueID);
		v1.setvenueaddress(venueAddress);
		
		
		Venue status1 ;
		VenueDao vd = new VenueDao();
		status1 = vd.addVenueDetails(v1);
		if(status1 != null)
		{
			logger.info("added successfully");
		}
		else
		{
			logger.info("not added");
		}
		out.close();
		 }catch(Exception e)
		 {
			 logger.fatal(e);
		 }

	}

}
