package com.virtusa.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.LP;
import com.virtusa.dao.LPDaoImplementation;


@WebServlet("/LpView")
public class LpView extends HttpServlet {
	static final Logger logger = Logger.getLogger(LpView.class);

	@Override

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PropertyConfigurator.configure("G:\\\\java project workspace\\\\LP Batch\\\\src\\\\log4j.properties");

		 response.setContentType("text/html"); 
		 try
		 {
			PrintWriter out = response.getWriter();
		
			out.println("<h1>LPS LIST</h1>");
			LPDaoImplementation lpd = new LPDaoImplementation();
			List<LP> lPlist = lpd.getAllLPS();
			out.print("<table border = '1' width='100%'");
			out.print("<tr><th>lppass</th><th>lpid</th><th>LP_Name</th><th>PHNO</th><th>Email</th><th>batchid</th>"
					+ "<th>VenueID</th><th>Edited</th></tr>");
			for (LP l1 : lPlist)
			{
				out.print("<tr><td>"+l1.getlppass()+"</td><td>"+l1.getlpid()+"</td><td>"+l1.getLPName()+"</td><td>"
						+l1.getPhno()+"</td><td>"+l1.getEmail()+"</td><td>"
						+l1.getbatchid()+"</td><td>"+l1.getvenueid()+
						"\"</td><td>\"<a href='LPUpdateServlet?lpid="+l1.getlpid()+"'>Edited</a></td></tr>");
				
			}
			out.print("</table>");
			
			out.close();
	}catch(Exception e)
		 {
		   logger.fatal(e);
		 }
	}

	

}
