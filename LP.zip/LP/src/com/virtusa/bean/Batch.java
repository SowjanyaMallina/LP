package com.virtusa.bean;

public class Batch
{
	private int batchid;
	private int venueid;
	private int cid;
	private int mentorid;
	private String batchname;
	public int getbatchid() {
		return batchid;
	}
	public void setbatchid(int batchid) {
		this.batchid = batchid;
	}
	public int getvenueid() {
		return venueid;
	}
	public void setvenueid(int venueid) {
		this.venueid = venueid;
	}
	public int getmentorid() {
		return mentorid;
	}
	public void setmentorid(int mentorid) {
		this.mentorid = mentorid;
	}
	public int getcid() {
		return cid;
	}
	public void setcid(int cid) {
		this.cid = cid;
	}
	public String getbatchname() {
		return batchname;
	}
	public void setbatchname(String batchname) {
		this.batchname = batchname;
	}
	  
}
