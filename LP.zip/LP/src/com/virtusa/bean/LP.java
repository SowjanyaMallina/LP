package com.virtusa.bean;

public class LP 
{
	private String lpname;
	private String email;
	private String lppass;
	private int phno;
	private int lpid;
	private int batchid;
	private int venueid;
	
	public int getvenueid() {
		return venueid;
	}
	public void setvenueid(int venueid) {
		this.venueid = venueid;
	}
	public LP() {
		super();
		
	}
	public LP(String lppass, int lpid) {
		super();
		this.lppass = lppass;
		this.lpid = lpid;
	}
	public String getLPName() {
		return lpname;
	}
	public void setLPName(String lPName) {
		this.lpname = lPName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getlppass() {
		return lppass;
	}
	public void setlppass(String lppass) {
		this.lppass = lppass;
	}
	public int getPhno() {
		return phno;
	}
	public void setPhno(int phno) {
		this.phno = phno;
	}
	public int getlpid() {
		return lpid;
	}
	public void setlpid(int lpid) {
		this.lpid = lpid;
	}
	
	public int getbatchid() {
		return batchid;
	}
	public void setbatchid(int batchid) {
		this.batchid = batchid;
	}
	
	
}
