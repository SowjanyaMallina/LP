package com.virtusa.bean;

public class Venue
{
	private int venueid;
	private String venueaddress;
	public int getvenueid() {
		return venueid;
	}
	public void setvenueid(int venueid) {
		this.venueid = venueid;
	}
	public String getvenueaddress() {
		return venueaddress;
	}
	public void setvenueaddress(String venueaddress) {
		this.venueaddress = venueaddress;
	}
	
}
