package com.virtusa.bean;

public class Admin
{
	private String adminpass;
	private int adminid;
	
	public Admin(String adminpass, int adminid) {
		super();
		this.adminpass = adminpass;
		this.adminid = adminid;
	}
	public String getadminpass() {
		return adminpass;
	}
	public void setadminpass(String adminpass) {
		this.adminpass = adminpass;
	}
	public int getadminid() {
		return adminid;
	}
	public void setadminid(int adminid) {
		this.adminid = adminid;
	}
}
