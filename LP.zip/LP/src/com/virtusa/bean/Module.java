package com.virtusa.bean;

public class Module 
{
	private int moduleid;
	private int batchid;
	private String modulename;
	private String  schedule;
	public int getmoduleid() {
		return moduleid;
	}
	public void setmoduleid(int moduleid) {
		this.moduleid = moduleid;
	}
	public int getbatchid() {
		return batchid;
	}
	public void setbatchid(int batchid) {
		this.batchid = batchid;
	}
	public String getmodulename() {
		return modulename;
	}
	public void setmodulename(String modulename) {
		this.modulename = modulename;
	}
	public String getSchedule() {
		return schedule;
	}
	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}
	
}
