package com.virtusa.bean;

public class Mentor 
{
	private String mentorpass;
	private int mentorid;
	private long  phno;
	private String email;
	private String mentorname;
	private int venueid;
	
	
	public Mentor() {
		super();

	}
	public Mentor(String mentorpass, int mentorid) {
		super();
		this.mentorpass = mentorpass;
		this.mentorid = mentorid;
	}
	public int getvenueid() {
		return venueid;
	}
	public void setvenueid(int venueid) {
		this.venueid = venueid;
	}
	public String getmentorpass() {
		return mentorpass;
	}
	public void setmentorpass(String mentorpass) {
		this.mentorpass = mentorpass;
	}
	public int getmentorid() {
		return mentorid;
	}
	public void setmentorid(int mentorid) {
		this.mentorid = mentorid;
	}
	public long getPhno() {
		return phno;
	}
	public void setPhno(long phno) {
		this.phno = phno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getmentorname() {
		return mentorname;
	}
	public void setmentorname(String mentorname) {
		this.mentorname = mentorname;
	}
	
	
}
